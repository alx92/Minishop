package com.company.sda.ui;

import com.company.sda.persistence.model.UserModel;
import com.company.sda.service.UserService;

import java.util.List;
import java.util.Scanner;

public class UserManagementUI {

    public void startProgram(){
        UserService userService =  new UserService();
        Scanner scanner = new Scanner(System.in);
        int option = -1;
        while(option != 0){
            System.out.println("0.Exit");
            System.out.println("1.View users");
            System.out.println("2.Add user");
            System.out.println("3.Change name");
            option =  scanner.nextInt();
            scanner.nextLine();
            if(option == 1){
                List<UserModel> userModelList = userService.getSortedUsers();
                userModelList.forEach(userModel -> System.out.println(userModel.getId() +
                        "." + userModel.getLastName() + " " + userModel.getName()));
            }
            if(option == 2){
                System.out.println("Enter last name:");
                String lastName =  scanner.nextLine();
                System.out.println("Enter name");
                String name =  scanner.nextLine();
                UserModel newUserModel =  new UserModel();
                newUserModel.setLastName(lastName);
                newUserModel.setName(name);
                userService.addUser(newUserModel);
            }
        }

    }

}

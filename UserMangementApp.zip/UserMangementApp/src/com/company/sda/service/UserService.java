package com.company.sda.service;

import com.company.sda.persistence.dao.UserDao;
import com.company.sda.persistence.model.UserModel;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class UserService {

    private UserDao userDao = new UserDao();

    public void addUser(UserModel userModel){
        userModel.setId(System.currentTimeMillis());
        userDao.addUser(userModel);
    }

    public List<UserModel> getSortedUsers(){
        List<UserModel> users = userDao.readUsers();
        users.sort(Comparator.comparing(user -> (user.getLastName() + user.getName())));
        return users;
    }

    public void changeName(String newName, int id){
        Optional<UserModel> optional = userDao.readUser(id);
        if(optional.isPresent()){
            UserModel userModel = optional.get();
            userModel.setName(newName);
            userDao.update(userModel);
        }
    }
}
